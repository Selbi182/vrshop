OBJ IMPORTER README:

This is the readme for aaro4130's OBJ Import Asset. This asset
can import OBJ files at runtime or in the editor--

--Importing an OBJ from another script--
OBJLoader.LoadOBJFile(string filepath) will return a GameObject with the resulting import.

--Importing an OBJ in the editor--
Import via GameObject->Import from OBJ