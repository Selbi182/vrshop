﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class BuildAssetBundles : Editor {

	[MenuItem("Assets/ Build AssetBundle")]
    static void BuildAssets() {
        BuildPipeline.BuildAssetBundles(@"C:\Users\Borsti\Desktop\obj\obj", BuildAssetBundleOptions.ChunkBasedCompression, BuildTarget.StandaloneWindows64);
    }
}
