﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor; 
using System.IO;

public class ImportModel : MonoBehaviour {

    public bool loadObj = false;

    void Update() {
        if (loadObj) {
            loadObj = false;


            string path = @"C:\Users\Borsti\Desktop\assetbundle\";
            string objPath = @"stapler";

            AssetBundle ab = AssetBundle.LoadFromFile(path + objPath);
            if (ab == null) {
                Debug.Log("error");

            }

            // Instantiate the object ("model") is the name of the .obj file before compression
            GameObject g = ab.LoadAsset("model") as GameObject;

            // Find the GameObject that contains the MeshRenderer and instantiate that object
            g = g.GetComponentInChildren<MeshRenderer>().gameObject;

            // Scale the object
            float scaleFactor = 0.01f;
            g.transform.localScale = new Vector3(scaleFactor, scaleFactor, scaleFactor);
            
            // Add a MeshCollider to this object with reduced polycount
            MeshCollider mc = g.AddComponent<MeshCollider>();
            mc.cookingOptions = MeshColliderCookingOptions.InflateConvexMesh | mc.cookingOptions;
            mc.convex = true;

            // Enable gravity by adding a Rigidbody
            Rigidbody r = g.AddComponent<Rigidbody>();
            r.useGravity = false;

            Instantiate(g);
        }
    }
}
