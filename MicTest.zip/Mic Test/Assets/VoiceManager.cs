﻿using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Windows.Speech;
using Mono.Data.Sqlite;
using System.Data;
using System;
using System.IO;

public class VoiceManager : MonoBehaviour {

    class Article {
        public string name;
        public byte[] image;
    }

    private DictationRecognizer dictationRecognizer;

    public GameObject textObj;
    public GameObject imgObj;

    public bool isRecording;
    private bool _recording;

    //https://answers.unity.com/questions/743400/database-sqlite-setup-for-unity.html

    private string dbPath;
    private const string DB_FILE_NAME = "vrshop.db";
    private const int DB_ARTICLES_ID_COLUMN = 0;
    private const int DB_ARTICLES_NAME_COLUMN = 1;
    private const int DB_ARTICLES_PRICE_COLUMN = 2;
    private const int DB_ARTICLES_DESCRIPTION_COLUMN = 3;
    private const int DB_ARTICLES_SIZE_COLUMN = 4;
    private const int DB_ARTICLES_THUMBNAIL_COLUMN = 5;

    private const string ARTICLE_SEARCH_STRING_PLACEHOLDER = "@ArticleSearchString";
    private readonly string ARTICLE_SEARCH_QUERY = string.Format(@"
        SELECT a.id, a.name, a.price, a.description, a.model_size, a.thumbnail FROM tbl_articles a
            WHERE
                a.name LIKE {0}
            OR
                a.category IN (
                    WITH parents AS (
                        SELECT id, name FROM tbl_categories
                            WHERE name LIKE {0}
                    )
                    SELECT c.id FROM tbl_categories c
                        JOIN parents
                            ON c.parent_id = parents.id
                        UNION
                            SELECT p.id FROM parents p
                )
            ORDER BY a.category DESC
    ", ARTICLE_SEARCH_STRING_PLACEHOLDER);

    void Start() {
        // Set up the path to the DB
        dbPath = string.Format("URI=file:{0}/{1}", Application.dataPath, DB_FILE_NAME);
        Debug.Log(dbPath);

        // Don't start the recognition yet
        isRecording = false;
        _recording = isRecording;

        // Initialize the dictation recognizer with all handlers
        dictationRecognizer = new DictationRecognizer();
        dictationRecognizer.DictationResult += (text, confidence) => {
            Debug.LogFormat("Dictation result: {0}", text);
            Article dbResult = SearchForArticle(text);
            if (textObj != null && dbResult != null) {
                textObj.GetComponent<TextMesh>().text = dbResult.name;

                if (dbResult.image != null) {
                    Texture2D tex;
                    tex = new Texture2D(4, 4, TextureFormat.DXT1, false);

                    tex.LoadImage(dbResult.image);
                    imgObj.GetComponent<Renderer>().material.mainTexture = tex;

                    
                }


            }
            isRecording = false;
            dictationRecognizer.Stop();
        };

        dictationRecognizer.DictationComplete += (completionCause) => {
            if (completionCause != DictationCompletionCause.Complete) {
                Debug.LogErrorFormat("Dictation completed unsuccessfully: {0}.", completionCause);
            }
        };

        dictationRecognizer.DictationError += (error, hresult) => {
            Debug.LogErrorFormat("Dictation error: {0}; HResult = {1}.", error, hresult);
        };
    }

    void Update() {
        // Enable/disable recording if the flag was toggled
        if (isRecording != _recording) {
            _recording = isRecording;
            if (isRecording) {
                dictationRecognizer.Start();
            } else {
                dictationRecognizer.Stop();
            }
        }
    }

    private Article SearchForArticle(string searchString) {
        using (var conn = new SqliteConnection(dbPath)) {
            conn.Open();
            using (var cmd = conn.CreateCommand()) {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = ARTICLE_SEARCH_QUERY;
                cmd.Parameters.AddWithValue(ARTICLE_SEARCH_STRING_PLACEHOLDER, string.Format("%{0}%", searchString));

                var reader = cmd.ExecuteReader();
                while (reader.Read()) {
                    var id = reader.GetInt32(DB_ARTICLES_ID_COLUMN);
                    var price = reader.GetDecimal(DB_ARTICLES_PRICE_COLUMN);
                    var articleName = reader.GetString(DB_ARTICLES_NAME_COLUMN);
                    var description = reader.GetString(DB_ARTICLES_DESCRIPTION_COLUMN);
                    var text = string.Format("({0}) {1} [{2}] - {3}", id, articleName, price, description);

                    byte[] img = (byte[])reader[DB_ARTICLES_THUMBNAIL_COLUMN];

                    Debug.Log(reader.GetDataTypeName(DB_ARTICLES_THUMBNAIL_COLUMN));

                    Article a = new Article {
                        name = text,
                        image = img
                    };
                    return a;
                }
            }
            conn.Close();
            return null;
        }
    }

    

    static byte[] GetBytes(SqliteDataReader reader) {
        const int CHUNK_SIZE = 2 * 1024;
        byte[] buffer = new byte[CHUNK_SIZE];
        long bytesRead;
        long fieldOffset = 0;
        using (MemoryStream stream = new MemoryStream()) {
            while ((bytesRead = reader.GetBytes(0, fieldOffset, buffer, 0, buffer.Length)) > 0) {
                stream.Write(buffer, 0, (int)bytesRead);
                fieldOffset += bytesRead;
            }
            return stream.ToArray();
        }
    }

}